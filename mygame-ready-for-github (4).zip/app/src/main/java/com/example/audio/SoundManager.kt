package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.sin

class SoundManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO)

    private val _isRecording = MutableStateFlow(false)
    val isRecording = _isRecording.asStateFlow()

    private val _isVoiceMuted = MutableStateFlow(false)
    val isVoiceMuted = _isVoiceMuted.asStateFlow()

    private val _isPlayingVoice = MutableStateFlow(false)
    val isPlayingVoice = _isPlayingVoice.asStateFlow()

    private val _activeSpeakerName = MutableStateFlow<String?>(null)
    val activeSpeakerName = _activeSpeakerName.asStateFlow()

    private val _audioLevel = MutableStateFlow(0f)
    val audioLevel = _audioLevel.asStateFlow()

    private var mediaRecorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private var mediaPlayer: MediaPlayer? = null
    private var recordStartTime: Long = 0L

    fun toggleVoiceMute() {
        _isVoiceMuted.value = !_isVoiceMuted.value
    }

    // --- SYNTHESIZED SOUND EFFECTS (Pure PCM, Zero External Files) ---

    private fun playTone(
        frequencies: List<Float>,
        durationMs: Int,
        volume: Float = 0.5f,
        harmonic: Boolean = false
    ) {
        scope.launch {
            try {
                val sampleRate = 44100
                val totalSamples = (sampleRate * (durationMs / 1000f)).toInt()
                val buffer = ShortArray(totalSamples)

                for (i in 0 until totalSamples) {
                    var sampleVal = 0.0
                    val time = i.toDouble() / sampleRate
                    for (freq in frequencies) {
                        val angle = 2.0 * Math.PI * freq * time
                        sampleVal += sin(angle)
                        if (harmonic) {
                            sampleVal += 0.3 * sin(2 * angle)
                        }
                    }
                    val envelope = if (i < totalSamples * 0.1) {
                        i.toDouble() / (totalSamples * 0.1)
                    } else {
                        1.0 - ((i - totalSamples * 0.1) / (totalSamples * 0.9))
                    }
                    val sample = (sampleVal / frequencies.size * volume * envelope * Short.MAX_VALUE).toInt()
                    buffer[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(buffer, 0, buffer.size)
                audioTrack.play()
                // Auto-release after playing
                scope.launch {
                    kotlinx.coroutines.delay(durationMs.toLong() + 100L)
                    audioTrack.release()
                }
            } catch (e: Exception) {
                Log.w("SoundManager", "Error playing sound tone: ${e.message}")
            }
        }
    }

    fun playDiceRoll() {
        scope.launch {
            for (f in listOf(220f, 330f, 440f, 550f, 660f, 440f)) {
                playTone(listOf(f), 45, 0.4f)
                kotlinx.coroutines.delay(50L)
            }
        }
    }

    fun playDiceResult() {
        playTone(listOf(587.33f, 880f), 220, 0.6f, true)
    }

    fun playTokenStep() {
        playTone(listOf(440f, 659.25f), 70, 0.4f)
    }

    fun playCapture() {
        scope.launch {
            playTone(listOf(880f, 659f), 100, 0.7f)
            kotlinx.coroutines.delay(90L)
            playTone(listOf(330f, 220f, 110f), 350, 0.8f, true)
        }
    }

    fun playSafeLand() {
        scope.launch {
            playTone(listOf(523.25f), 80, 0.5f)
            kotlinx.coroutines.delay(70L)
            playTone(listOf(659.25f), 80, 0.5f)
            kotlinx.coroutines.delay(70L)
            playTone(listOf(783.99f), 150, 0.6f)
        }
    }

    fun playVictory() {
        scope.launch {
            val notes = listOf(523.25f, 659.25f, 783.99f, 1046.50f)
            for (note in notes) {
                playTone(listOf(note), 150, 0.7f, true)
                kotlinx.coroutines.delay(120L)
            }
            playTone(listOf(1046.50f, 1318.51f), 500, 0.8f, true)
        }
    }

    // --- PUSH-TO-TALK (PTT) VOICE CHAT RECORDING & PLAYBACK ---

    fun startVoiceRecording(): Boolean {
        if (_isVoiceMuted.value) return false
        return try {
            val outputDir = context.cacheDir
            recordingFile = File.createTempFile("ludo_voice_", ".m4a", outputDir)
            mediaRecorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(22050)
                setAudioEncodingBitRate(32000)
                setOutputFile(recordingFile?.absolutePath)
                prepare()
                start()
            }
            recordStartTime = System.currentTimeMillis()
            _isRecording.value = true
            _audioLevel.value = 0.8f
            true
        } catch (e: Exception) {
            Log.e("SoundManager", "Failed to start voice recording", e)
            _isRecording.value = false
            false
        }
    }

    /**
     * Stops recording and returns (Base64 audio string, duration in ms)
     */
    fun stopVoiceRecording(): Pair<String, Long>? {
        if (!_isRecording.value) return null
        val duration = System.currentTimeMillis() - recordStartTime
        _isRecording.value = false
        _audioLevel.value = 0f

        return try {
            mediaRecorder?.apply {
                stop()
                release()
            }
            mediaRecorder = null

            val file = recordingFile ?: return null
            if (duration < 500 || !file.exists() || file.length() == 0L) {
                file.delete()
                return null
            }

            val bytes = FileInputStream(file).use { it.readBytes() }
            file.delete()
            val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            Pair(base64, duration)
        } catch (e: Exception) {
            Log.e("SoundManager", "Failed to finish voice recording", e)
            mediaRecorder?.release()
            mediaRecorder = null
            null
        }
    }

    fun playVoiceMessage(base64Audio: String, senderName: String) {
        if (_isVoiceMuted.value || base64Audio.isBlank()) return
        scope.launch {
            try {
                val bytes = Base64.decode(base64Audio, Base64.DEFAULT)
                val tempFile = File.createTempFile("playback_voice_", ".m4a", context.cacheDir)
                FileOutputStream(tempFile).use { it.write(bytes) }

                mediaPlayer?.release()
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(tempFile.absolutePath)
                    prepare()
                    setOnCompletionListener {
                        _isPlayingVoice.value = false
                        _activeSpeakerName.value = null
                        tempFile.delete()
                        release()
                    }
                    start()
                }
                _isPlayingVoice.value = true
                _activeSpeakerName.value = senderName
            } catch (e: Exception) {
                Log.e("SoundManager", "Failed to play voice message", e)
                _isPlayingVoice.value = false
                _activeSpeakerName.value = null
            }
        }
    }

    fun release() {
        mediaRecorder?.release()
        mediaRecorder = null
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
