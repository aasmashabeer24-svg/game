package com.example.game.engine

import com.example.game.model.PlayerColor
import com.example.game.model.Token

data class GridCoord(val row: Float, val col: Float)

object LudoBoardCoordinates {
    const val BOARD_SIZE = 15

    // Global 52 track step coordinates: (row, col)
    val TRACK_COORDS = listOf(
        GridCoord(6f, 1f),   // 0: Red Start (Safe)
        GridCoord(6f, 2f),   // 1
        GridCoord(6f, 3f),   // 2
        GridCoord(6f, 4f),   // 3
        GridCoord(6f, 5f),   // 4
        GridCoord(5f, 6f),   // 5
        GridCoord(4f, 6f),   // 6
        GridCoord(3f, 6f),   // 7
        GridCoord(2f, 6f),   // 8: Star (Safe)
        GridCoord(1f, 6f),   // 9
        GridCoord(0f, 6f),   // 10
        GridCoord(0f, 7f),   // 11
        GridCoord(0f, 8f),   // 12
        GridCoord(1f, 8f),   // 13: Green Start (Safe)
        GridCoord(2f, 8f),   // 14
        GridCoord(3f, 8f),   // 15
        GridCoord(4f, 8f),   // 16
        GridCoord(5f, 8f),   // 17
        GridCoord(6f, 9f),   // 18
        GridCoord(6f, 10f),  // 19
        GridCoord(6f, 11f),  // 20
        GridCoord(6f, 12f),  // 21: Star (Safe)
        GridCoord(6f, 13f),  // 22
        GridCoord(6f, 14f),  // 23
        GridCoord(7f, 14f),  // 24
        GridCoord(8f, 14f),  // 25
        GridCoord(8f, 13f),  // 26: Yellow Start (Safe)
        GridCoord(8f, 12f),  // 27
        GridCoord(8f, 11f),  // 28
        GridCoord(8f, 10f),  // 29
        GridCoord(8f, 9f),   // 30
        GridCoord(9f, 8f),   // 31
        GridCoord(10f, 8f),  // 32
        GridCoord(11f, 8f),  // 33
        GridCoord(12f, 8f),  // 34: Star (Safe)
        GridCoord(13f, 8f),  // 35
        GridCoord(14f, 8f),  // 36
        GridCoord(14f, 7f),  // 37
        GridCoord(14f, 6f),  // 38
        GridCoord(13f, 6f),  // 39: Blue Start (Safe)
        GridCoord(12f, 6f),  // 40
        GridCoord(11f, 6f),  // 41
        GridCoord(10f, 6f),  // 42
        GridCoord(9f, 6f),   // 43
        GridCoord(8f, 5f),   // 44
        GridCoord(8f, 4f),   // 45
        GridCoord(8f, 3f),   // 46
        GridCoord(8f, 2f),   // 47: Star (Safe)
        GridCoord(8f, 1f),   // 48
        GridCoord(8f, 0f),   // 49
        GridCoord(7f, 0f),   // 50
        GridCoord(6f, 0f)    // 51
    )

    // The 8 safe track indices (4 starts + 4 stars)
    val SAFE_TRACK_INDICES = setOf(0, 8, 13, 21, 26, 34, 39, 47)

    // Home paths per color (5 steps leading inward to goal)
    val RED_HOME_PATH = listOf(
        GridCoord(7f, 1f), GridCoord(7f, 2f), GridCoord(7f, 3f), GridCoord(7f, 4f), GridCoord(7f, 5f)
    )
    val GREEN_HOME_PATH = listOf(
        GridCoord(1f, 7f), GridCoord(2f, 7f), GridCoord(3f, 7f), GridCoord(4f, 7f), GridCoord(5f, 7f)
    )
    val YELLOW_HOME_PATH = listOf(
        GridCoord(7f, 13f), GridCoord(7f, 12f), GridCoord(7f, 11f), GridCoord(7f, 10f), GridCoord(7f, 9f)
    )
    val BLUE_HOME_PATH = listOf(
        GridCoord(13f, 7f), GridCoord(12f, 7f), GridCoord(11f, 7f), GridCoord(10f, 7f), GridCoord(9f, 7f)
    )

    // Center goals
    val RED_GOAL = GridCoord(7f, 6f)
    val GREEN_GOAL = GridCoord(6f, 7f)
    val YELLOW_GOAL = GridCoord(7f, 8f)
    val BLUE_GOAL = GridCoord(8f, 7f)

    // Yard base pockets for 4 tokens per color
    val YARD_COORDS = mapOf(
        PlayerColor.RED to listOf(
            GridCoord(1.8f, 1.8f), GridCoord(1.8f, 3.8f), GridCoord(3.8f, 1.8f), GridCoord(3.8f, 3.8f)
        ),
        PlayerColor.GREEN to listOf(
            GridCoord(1.8f, 10.8f), GridCoord(1.8f, 12.8f), GridCoord(3.8f, 10.8f), GridCoord(3.8f, 12.8f)
        ),
        PlayerColor.YELLOW to listOf(
            GridCoord(10.8f, 10.8f), GridCoord(10.8f, 12.8f), GridCoord(12.8f, 10.8f), GridCoord(12.8f, 12.8f)
        ),
        PlayerColor.BLUE to listOf(
            GridCoord(10.8f, 1.8f), GridCoord(10.8f, 3.8f), GridCoord(12.8f, 1.8f), GridCoord(12.8f, 3.8f)
        )
    )

    fun getTokenGridCoord(token: Token): GridCoord {
        if (token.isInYard) {
            val list = YARD_COORDS[token.color] ?: YARD_COORDS[PlayerColor.RED]!!
            return list.getOrElse(token.id) { list[0] }
        }
        if (token.isFinished) {
            return when (token.color) {
                PlayerColor.RED -> RED_GOAL
                PlayerColor.GREEN -> GREEN_GOAL
                PlayerColor.YELLOW -> YELLOW_GOAL
                PlayerColor.BLUE -> BLUE_GOAL
            }
        }
        if (token.isInHomePath) {
            val step = token.homePathStep.coerceIn(0, 4)
            return when (token.color) {
                PlayerColor.RED -> RED_HOME_PATH[step]
                PlayerColor.GREEN -> GREEN_HOME_PATH[step]
                PlayerColor.YELLOW -> YELLOW_HOME_PATH[step]
                PlayerColor.BLUE -> BLUE_HOME_PATH[step]
            }
        }
        val trackIdx = token.trackIndex
        return if (trackIdx in TRACK_COORDS.indices) {
            TRACK_COORDS[trackIdx]
        } else {
            TRACK_COORDS[0]
        }
    }
}
