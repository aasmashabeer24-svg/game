package com.example.game.model

/**
 * Representation of an individual token on the Ludo board.
 *
 * @param id Unique identifier (0..3 per color)
 * @param color PlayerColor of the token
 * @param stepProgress Total steps traveled from base (0: in yard, 1..51: on main track, 52..56: in home path, 57: finished home)
 */
data class Token(
    val id: Int,
    val color: PlayerColor,
    val stepProgress: Int = 0 // 0 means in yard; 1 means on start tile; 57 means in goal
) {
    val isInYard: Boolean get() = stepProgress == 0
    val isFinished: Boolean get() = stepProgress >= 57
    val isOnTrack: Boolean get() = stepProgress in 1..51
    val isInHomePath: Boolean get() = stepProgress in 52..56

    /**
     * Calculates the 0..51 global board track index when token is on the main loop.
     */
    val trackIndex: Int
        get() {
            if (!isOnTrack) return -1
            return (color.startTrackIndex + (stepProgress - 1)) % 52
        }

    /**
     * Home path step (0..4) corresponding to home path track.
     */
    val homePathStep: Int
        get() {
            if (!isInHomePath) return -1
            return stepProgress - 52
        }
}
