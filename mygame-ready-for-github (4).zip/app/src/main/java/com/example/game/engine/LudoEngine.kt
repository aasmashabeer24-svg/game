package com.example.game.engine

import com.example.game.model.PlayerColor
import com.example.game.model.Token
import org.json.JSONArray
import org.json.JSONObject

data class MoveResult(
    val updatedTokens: List<Token>,
    val capturedToken: Token?,
    val reachedGoal: Boolean,
    val grantsExtraRoll: Boolean,
    val winner: PlayerColor?
)

object LudoEngine {

    const val MAX_STEPS = 57 // Step 57 is Goal

    fun createInitialTokens(activeColors: List<PlayerColor>): List<Token> {
        val tokens = mutableListOf<Token>()
        for (color in activeColors) {
            for (id in 0..3) {
                tokens.add(Token(id = id, color = color, stepProgress = 0))
            }
        }
        return tokens
    }

    /**
     * Serializes token list to compact JSON string for Firestore syncing.
     */
    fun serializeTokens(tokens: List<Token>): String {
        val array = JSONArray()
        for (t in tokens) {
            val obj = JSONObject()
            obj.put("c", t.color.key)
            obj.put("id", t.id)
            obj.put("s", t.stepProgress)
            array.put(obj)
        }
        return array.toString()
    }

    /**
     * Deserializes token list from JSON string.
     */
    fun deserializeTokens(jsonString: String): List<Token> {
        if (jsonString.isBlank() || jsonString == "{}") return emptyList()
        val tokens = mutableListOf<Token>()
        try {
            val array = JSONArray(jsonString)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val color = PlayerColor.fromKey(obj.getString("c"))
                val id = obj.getInt("id")
                val step = obj.getInt("s")
                tokens.add(Token(id = id, color = color, stepProgress = step))
            }
        } catch (_: Exception) {
            // fallback if corrupted
        }
        return tokens
    }

    /**
     * Finds all tokens of [activeColor] that can legally move with [diceRoll].
     */
    fun getValidMovableTokens(
        tokens: List<Token>,
        activeColor: PlayerColor,
        diceRoll: Int
    ): List<Token> {
        val colorTokens = tokens.filter { it.color == activeColor && !it.isFinished }
        val valid = mutableListOf<Token>()

        for (token in colorTokens) {
            if (token.isInYard) {
                if (diceRoll == 6) {
                    valid.add(token)
                }
            } else {
                val targetStep = token.stepProgress + diceRoll
                if (targetStep <= MAX_STEPS) {
                    valid.add(token)
                }
            }
        }
        return valid
    }

    /**
     * Executes moving [tokenToMove] by [diceRoll] steps.
     */
    fun executeMove(
        allTokens: List<Token>,
        tokenToMove: Token,
        diceRoll: Int
    ): MoveResult {
        val currentTokens = allTokens.toMutableList()
        val index = currentTokens.indexOfFirst { it.color == tokenToMove.color && it.id == tokenToMove.id }
        if (index == -1) {
            return MoveResult(allTokens, null, false, false, null)
        }

        val newStepProgress = if (tokenToMove.isInYard) {
            1 // Move out onto start square
        } else {
            tokenToMove.stepProgress + diceRoll
        }

        val updatedToken = tokenToMove.copy(stepProgress = newStepProgress)
        currentTokens[index] = updatedToken

        var capturedToken: Token? = null
        var grantsExtraRoll = diceRoll == 6
        val reachedGoal = updatedToken.isFinished

        if (reachedGoal) {
            grantsExtraRoll = true
        }

        // Check capture on main track if token is on track and not on safe square
        if (updatedToken.isOnTrack) {
            val targetTrackIdx = updatedToken.trackIndex
            val isSafeSquare = LudoBoardCoordinates.SAFE_TRACK_INDICES.contains(targetTrackIdx)
            if (!isSafeSquare) {
                // Find opponents at targetTrackIdx
                val opponentIndex = currentTokens.indexOfFirst {
                    it.color != updatedToken.color && it.isOnTrack && it.trackIndex == targetTrackIdx
                }
                if (opponentIndex != -1) {
                    val captured = currentTokens[opponentIndex]
                    currentTokens[opponentIndex] = captured.copy(stepProgress = 0)
                    capturedToken = captured
                    grantsExtraRoll = true
                }
            }
        }

        // Check win condition for active color
        val allFinished = currentTokens.filter { it.color == updatedToken.color }.all { it.isFinished }
        val winner = if (allFinished) updatedToken.color else null

        return MoveResult(
            updatedTokens = currentTokens,
            capturedToken = capturedToken,
            reachedGoal = reachedGoal,
            grantsExtraRoll = grantsExtraRoll,
            winner = winner
        )
    }

    /**
     * Pick best move for an AI Bot.
     */
    fun chooseBestBotMove(
        validTokens: List<Token>,
        allTokens: List<Token>,
        diceRoll: Int
    ): Token {
        if (validTokens.size == 1) return validTokens[0]

        // 1. Prioritize capturing an opponent
        for (token in validTokens) {
            if (!token.isInYard) {
                val targetStep = token.stepProgress + diceRoll
                if (targetStep <= 51) {
                    val targetTrack = (token.color.startTrackIndex + (targetStep - 1)) % 52
                    if (!LudoBoardCoordinates.SAFE_TRACK_INDICES.contains(targetTrack)) {
                        val hasOpponent = allTokens.any {
                            it.color != token.color && it.isOnTrack && it.trackIndex == targetTrack
                        }
                        if (hasOpponent) return token
                    }
                }
            }
        }

        // 2. Prioritize reaching home goal
        val goalToken = validTokens.firstOrNull { (it.stepProgress + diceRoll) == MAX_STEPS }
        if (goalToken != null) return goalToken

        // 3. Move token out of yard if 6
        if (diceRoll == 6) {
            val yardToken = validTokens.firstOrNull { it.isInYard }
            if (yardToken != null) return yardToken
        }

        // 4. Move token into safe square
        for (token in validTokens) {
            if (!token.isInYard) {
                val targetStep = token.stepProgress + diceRoll
                if (targetStep <= 51) {
                    val targetTrack = (token.color.startTrackIndex + (targetStep - 1)) % 52
                    if (LudoBoardCoordinates.SAFE_TRACK_INDICES.contains(targetTrack)) {
                        return token
                    }
                }
            }
        }

        // 5. Default: advance the most forward non-yard token
        return validTokens.maxByOrNull { it.stepProgress } ?: validTokens[0]
    }
}
