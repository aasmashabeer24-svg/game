package com.example.game.model

import androidx.compose.ui.graphics.Color

enum class PlayerColor(
    val key: String,
    val displayName: String,
    val primaryColor: Color,
    val lightColor: Color,
    val darkColor: Color,
    val startTrackIndex: Int, // Global track index (0..51) where this color enters
    val homeEntryTrackIndex: Int // Global track index before turning into home path
) {
    RED(
        key = "red",
        displayName = "Crimson Red",
        primaryColor = Color(0xFFE53935),
        lightColor = Color(0xFFFFCDD2),
        darkColor = Color(0xFFB71C1C),
        startTrackIndex = 0,
        homeEntryTrackIndex = 50
    ),
    GREEN(
        key = "green",
        displayName = "Emerald Green",
        primaryColor = Color(0xFF43A047),
        lightColor = Color(0xFFC8E6C9),
        darkColor = Color(0xFF1B5E20),
        startTrackIndex = 13,
        homeEntryTrackIndex = 11
    ),
    YELLOW(
        key = "yellow",
        displayName = "Golden Yellow",
        primaryColor = Color(0xFFFDD835),
        lightColor = Color(0xFFFFF9C4),
        darkColor = Color(0xFFF57F17),
        startTrackIndex = 26,
        homeEntryTrackIndex = 24
    ),
    BLUE(
        key = "blue",
        displayName = "Sapphire Blue",
        primaryColor = Color(0xFF1E88E5),
        lightColor = Color(0xFFBBDEFB),
        darkColor = Color(0xFF0D47A1),
        startTrackIndex = 39,
        homeEntryTrackIndex = 37
    );

    companion object {
        fun fromKey(key: String): PlayerColor {
            return entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: RED
        }
    }
}
