package com.example

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import com.example.data.repository.LudoRepository
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.GameScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LobbyScreen
import com.example.ui.theme.LudoGGTheme
import com.example.ui.theme.NightBackground
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

sealed interface Screen {
    data object Auth : Screen
    data object Home : Screen
    data class Lobby(val matchId: String) : Screen
    data class OnlineGame(val matchId: String) : Screen
    data class LocalGame(val playerCount: Int) : Screen
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Ensure FirebaseApp is safely initialized on startup
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseApp.initializeApp(this)
            }
        } catch (e: Exception) {
            Log.e("MainActivity", "Failed to initialize FirebaseApp", e)
        }

        val repository: LudoRepository? = try {
            val databaseId = getString(R.string.firestore_database_id)
            val firestore = FirebaseFirestore.getInstance(databaseId)
            LudoRepository(firestore)
        } catch (e: Exception) {
            Log.e("MainActivity", "Failed to initialize Firestore", e)
            null
        }

        setContent {
            LudoGGTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = NightBackground
                ) {
                    AppContent(repository = repository)
                }
            }
        }
    }
}

@Composable
fun AppContent(repository: LudoRepository?) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var currentUser by remember {
        mutableStateOf(
            try {
                Firebase.auth.currentUser
            } catch (_: Exception) {
                null
            }
        )
    }
    var currentScreen by remember {
        mutableStateOf<Screen>(
            if (currentUser != null) Screen.Home else Screen.Auth
        )
    }

    DisposableEffect(Unit) {
        val authInstance = try {
            Firebase.auth
        } catch (_: Exception) {
            null
        }

        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
            if (auth.currentUser != null && currentScreen == Screen.Auth) {
                currentScreen = Screen.Home
            }
        }

        authInstance?.addAuthStateListener(listener)
        onDispose {
            authInstance?.removeAuthStateListener(listener)
        }
    }

    when (val screen = currentScreen) {
        is Screen.Auth -> {
            AuthScreen(
                onAuthSuccess = {
                    currentUser = Firebase.auth.currentUser
                    currentScreen = Screen.Home
                },
                onPlayOffline = {
                    currentScreen = Screen.LocalGame(4)
                }
            )
        }
        is Screen.Home -> {
            val uid = currentUser?.uid ?: "local_guest"
            if (repository != null) {
                HomeScreen(
                    currentUserId = uid,
                    repository = repository,
                    onStartLocalGame = { count ->
                        currentScreen = Screen.LocalGame(count)
                    },
                    onJoinOnlineRoom = { matchId ->
                        currentScreen = Screen.Lobby(matchId)
                    },
                    onSignOut = {
                        scope.launch {
                            try {
                                Firebase.auth.signOut()
                                val cm = CredentialManager.create(context)
                                cm.clearCredentialState(ClearCredentialStateRequest())
                            } catch (_: Exception) {}
                            currentUser = null
                            currentScreen = Screen.Auth
                        }
                    }
                )
            } else {
                // If repository is unavailable, provide local game immediately
                GameScreen(
                    matchId = null,
                    currentUserId = uid,
                    repository = null,
                    localPlayerCount = 4,
                    onExitGame = {
                        currentScreen = Screen.Auth
                    }
                )
            }
        }
        is Screen.Lobby -> {
            val uid = currentUser?.uid ?: "guest"
            if (repository != null) {
                LobbyScreen(
                    matchId = screen.matchId,
                    currentUserId = uid,
                    repository = repository,
                    onGameStarted = {
                        currentScreen = Screen.OnlineGame(screen.matchId)
                    },
                    onLeaveLobby = {
                        currentScreen = if (currentUser != null) Screen.Home else Screen.Auth
                    }
                )
            } else {
                currentScreen = Screen.LocalGame(4)
            }
        }
        is Screen.OnlineGame -> {
            val uid = currentUser?.uid ?: "guest"
            GameScreen(
                matchId = screen.matchId,
                currentUserId = uid,
                repository = repository,
                onExitGame = {
                    currentScreen = if (currentUser != null) Screen.Home else Screen.Auth
                }
            )
        }
        is Screen.LocalGame -> {
            val uid = currentUser?.uid ?: "local_player"
            GameScreen(
                matchId = null,
                currentUserId = uid,
                repository = null,
                localPlayerCount = screen.playerCount,
                onExitGame = {
                    currentScreen = if (currentUser != null) Screen.Home else Screen.Auth
                }
            )
        }
    }
}
