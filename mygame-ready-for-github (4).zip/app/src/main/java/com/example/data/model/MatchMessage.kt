package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class MatchMessage(
    val id: String = "",
    val matchId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val type: String = "chat", // "chat", "emoji", "voice"
    val content: String = "",
    val durationMs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)
