package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class MatchRoom(
    val id: String = "",
    val roomCode: String = "",
    val hostId: String = "",
    val status: String = "waiting", // "waiting", "playing", "finished"
    val playerCount: Long = 4L,
    val playerIds: List<String> = emptyList(),
    val playerNames: List<String> = emptyList(),
    val playerColors: List<String> = emptyList(),
    val currentTurnIndex: Long = 0L,
    val currentTurnPlayerId: String = "",
    val lastDiceRoll: Long = 1L,
    val hasRolled: Boolean = false,
    val tokensState: String = "{}",
    val winnerId: String = "",
    val winnerColor: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
