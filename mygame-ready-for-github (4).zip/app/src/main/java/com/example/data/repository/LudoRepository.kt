package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.MatchMessage
import com.example.data.model.MatchRoom
import com.example.data.model.UserProfile
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class LudoRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before performing database operations.")
    }

    // User Profile
    fun observeUserProfile(userId: String): Flow<UserProfile?> {
        val path = "users/$userId"
        return db.collection("users").document(userId)
            .snapshots()
            .map { it.toObject(UserProfile::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.GET, path)
                throw e
            }
    }

    suspend fun saveUserProfile(displayName: String, avatarId: String): Result<Unit> {
        val uid = requireUserId()
        val path = "users/$uid"
        val docRef = db.collection("users").document(uid)
        return try {
            val snapshot = docRef.get().await()
            if (snapshot.exists()) {
                val existingProfile = snapshot.toObject(UserProfile::class.java)
                docRef.update(
                    mapOf(
                        "displayName" to displayName,
                        "avatarId" to avatarId,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                val newProfileMap = mapOf(
                    "userId" to uid,
                    "displayName" to displayName,
                    "avatarId" to avatarId,
                    "gamesPlayed" to 0L,
                    "gamesWon" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(newProfileMap).await()
            }
            Result.success(Unit)
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun recordGameFinished(isWinner: Boolean): Result<Unit> {
        val uid = requireUserId()
        val path = "users/$uid"
        val docRef = db.collection("users").document(uid)
        return try {
            val updates = mutableMapOf<String, Any>(
                "gamesPlayed" to FieldValue.increment(1L),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (isWinner) {
                updates["gamesWon"] = FieldValue.increment(1L)
            }
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // Matches
    fun observeWaitingMatches(): Flow<List<MatchRoom>> {
        val path = "matches"
        return db.collection("matches")
            .whereEqualTo("status", "waiting")
            .snapshots()
            .map { snapshot -> snapshot.toObjects(MatchRoom::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                throw e
            }
    }

    fun observeMatch(matchId: String): Flow<MatchRoom?> {
        val path = "matches/$matchId"
        return db.collection("matches").document(matchId)
            .snapshots()
            .map { it.toObject(MatchRoom::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.GET, path)
                throw e
            }
    }

    suspend fun createMatch(
        roomCode: String,
        playerCount: Long,
        playerName: String,
        playerColor: String = "red"
    ): Result<String> {
        val uid = requireUserId()
        val docRef = db.collection("matches").document()
        val matchId = docRef.id
        val payload = mapOf(
            "id" to matchId,
            "roomCode" to roomCode,
            "hostId" to uid,
            "status" to "waiting",
            "playerCount" to playerCount,
            "playerIds" to listOf(uid),
            "playerNames" to listOf(playerName),
            "playerColors" to listOf(playerColor),
            "currentTurnIndex" to 0L,
            "currentTurnPlayerId" to uid,
            "lastDiceRoll" to 6L,
            "hasRolled" to false,
            "tokensState" to "{}",
            "winnerId" to "",
            "winnerColor" to "",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(matchId)
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun joinMatch(matchId: String, playerName: String, playerColor: String): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("matches").document(matchId)
        return try {
            val snapshot = docRef.get().await()
            val match = snapshot.toObject(MatchRoom::class.java)
                ?: return Result.failure(IllegalStateException("Match not found"))

            if (match.status != "waiting") {
                return Result.failure(IllegalStateException("Match already started or finished"))
            }
            if (match.playerIds.contains(uid)) {
                return Result.success(Unit) // Already joined
            }
            if (match.playerIds.size >= match.playerCount.toInt()) {
                return Result.failure(IllegalStateException("Match is already full"))
            }

            val newPlayerIds = match.playerIds + uid
            val newPlayerNames = match.playerNames + playerName
            val newPlayerColors = match.playerColors + playerColor

            val updates = mutableMapOf<String, Any>(
                "playerIds" to newPlayerIds,
                "playerNames" to newPlayerNames,
                "playerColors" to newPlayerColors,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateMatchState(
        matchId: String,
        updates: Map<String, Any>
    ): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("matches").document(matchId)
        val payload = updates + mapOf("updatedAt" to FieldValue.serverTimestamp())
        return try {
            docRef.update(payload).await()
            Result.success(Unit)
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    // Messages and Voice Clips
    fun observeMessages(matchId: String): Flow<List<MatchMessage>> {
        val path = "matches/$matchId/messages"
        return db.collection("matches").document(matchId).collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .snapshots()
            .map { snapshot -> snapshot.toObjects(MatchMessage::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                throw e
            }
    }

    suspend fun sendMessage(
        matchId: String,
        senderName: String,
        type: String, // "chat", "emoji", "voice"
        content: String,
        durationMs: Long = 0L
    ): Result<String> {
        val uid = requireUserId()
        val messagesRef = db.collection("matches").document(matchId).collection("messages")
        val docRef = messagesRef.document()
        val payload = mapOf(
            "id" to docRef.id,
            "matchId" to matchId,
            "senderId" to uid,
            "senderName" to senderName,
            "type" to type,
            "content" to content,
            "durationMs" to durationMs,
            "createdAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, messagesRef.path)
            Result.failure(e)
        }
    }
}
