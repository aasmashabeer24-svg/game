package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.audio.SoundManager
import com.example.data.model.MatchMessage
import com.example.data.model.MatchRoom
import com.example.data.repository.LudoRepository
import com.example.game.engine.LudoEngine
import com.example.game.model.PlayerColor
import com.example.game.model.Token
import com.example.ui.components.DiceView
import com.example.ui.components.LudoBoard
import com.example.ui.components.PlayerCard
import com.example.ui.components.QuickChatModal
import com.example.ui.components.VoiceChatControls
import com.example.ui.theme.LudoGold
import com.example.ui.theme.NightBackground
import com.example.ui.theme.NightSurface
import com.example.ui.theme.NightSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(
    matchId: String?, // Null when Local / Pass & Play mode
    currentUserId: String,
    repository: LudoRepository?,
    localPlayerCount: Int = 4,
    onExitGame: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val soundManager = remember { SoundManager(context) }

    DisposableEffect(Unit) {
        onDispose {
            soundManager.release()
        }
    }

    // Permission launcher for Voice Chat
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            Toast.makeText(context, "Microphone permission needed for Voice Chat", Toast.LENGTH_SHORT).show()
        }
    }

    // Audio states from SoundManager
    val isRecordingVoice by soundManager.isRecording.collectAsStateWithLifecycle()
    val isVoiceMuted by soundManager.isVoiceMuted.collectAsStateWithLifecycle()
    val isPlayingVoice by soundManager.isPlayingVoice.collectAsStateWithLifecycle()
    val activeSpeakerName by soundManager.activeSpeakerName.collectAsStateWithLifecycle()

    var showQuickChatModal by remember { mutableStateOf(false) }
    var floatingReaction by remember { mutableStateOf<String?>(null) }

    // --- LOCAL / BOT MODE STATE ---
    var localTokens by remember {
        val colors = listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW, PlayerColor.BLUE).take(localPlayerCount)
        mutableStateOf(LudoEngine.createInitialTokens(colors))
    }
    var localActiveColorIndex by remember { mutableIntStateOf(0) }
    var localDiceRoll by remember { mutableIntStateOf(6) }
    var localHasRolled by remember { mutableStateOf(false) }
    var localWinner by remember { mutableStateOf<PlayerColor?>(null) }

    // --- ONLINE FIRESTORE SYNC ---
    val onlineMatch by (if (matchId != null && repository != null) {
        repository.observeMatch(matchId)
    } else {
        kotlinx.coroutines.flow.flowOf(null)
    }).collectAsStateWithLifecycle(initialValue = null)

    val onlineMessages by (if (matchId != null && repository != null) {
        repository.observeMessages(matchId)
    } else {
        kotlinx.coroutines.flow.flowOf(emptyList())
    }).collectAsStateWithLifecycle(initialValue = emptyList())

    // Automatically play latest incoming voice message
    var lastProcessedMessageId by remember { mutableStateOf("") }
    LaunchedEffect(onlineMessages) {
        val latest = onlineMessages.lastOrNull()
        if (latest != null && latest.id != lastProcessedMessageId) {
            lastProcessedMessageId = latest.id
            if (latest.type == "voice" && latest.senderId != currentUserId) {
                soundManager.playVoiceMessage(latest.content, latest.senderName)
            } else if (latest.type in listOf("emoji", "chat")) {
                floatingReaction = "${latest.senderName}: ${latest.content}"
                delay(3000L)
                floatingReaction = null
            }
        }
    }

    // Determine current active game state:
    val isOnline = matchId != null && onlineMatch != null
    val currentTokens: List<Token>
    val activeColor: PlayerColor
    val activePlayerId: String
    val activePlayerName: String
    val currentDiceValue: Int
    val hasRolled: Boolean
    val winner: PlayerColor?
    val allColors: List<PlayerColor>
    val allPlayerNames: List<String>
    val allPlayerIds: List<String>

    if (isOnline) {
        val m = onlineMatch!!
        currentTokens = LudoEngine.deserializeTokens(m.tokensState)
        allColors = m.playerColors.map { PlayerColor.fromKey(it) }
        allPlayerNames = m.playerNames
        allPlayerIds = m.playerIds

        val turnIdx = m.currentTurnIndex.toInt().coerceIn(0, allColors.lastIndex)
        activeColor = allColors[turnIdx]
        activePlayerId = allPlayerIds[turnIdx]
        activePlayerName = allPlayerNames[turnIdx]
        currentDiceValue = m.lastDiceRoll.toInt()
        hasRolled = m.hasRolled
        winner = if (m.winnerColor.isNotBlank()) PlayerColor.fromKey(m.winnerColor) else null
    } else {
        allColors = listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW, PlayerColor.BLUE).take(localPlayerCount)
        allPlayerNames = allColors.mapIndexed { idx, c -> if (idx == 0) "You" else "Bot ${c.name.lowercase().replaceFirstChar { it.uppercase() }}" }
        allPlayerIds = allColors.mapIndexed { idx, _ -> if (idx == 0) currentUserId else "bot_$idx" }

        val turnIdx = localActiveColorIndex.coerceIn(0, allColors.lastIndex)
        activeColor = allColors[turnIdx]
        activePlayerId = allPlayerIds[turnIdx]
        activePlayerName = allPlayerNames[turnIdx]
        currentTokens = localTokens
        currentDiceValue = localDiceRoll
        hasRolled = localHasRolled
        winner = localWinner
    }

    // Determine movable tokens
    val movableTokens = if (hasRolled && winner == null) {
        LudoEngine.getValidMovableTokens(currentTokens, activeColor, currentDiceValue)
    } else {
        emptyList()
    }

    var isRollingDice by remember { mutableStateOf(false) }
    val isMyTurn = activePlayerId == currentUserId
    val isBotTurn = activePlayerId.startsWith("bot_")

    // Handle bot automation
    LaunchedEffect(isBotTurn, hasRolled, isRollingDice, activePlayerId) {
        if (isBotTurn && winner == null) {
            if (!hasRolled && !isRollingDice) {
                delay(800L)
                isRollingDice = true
                soundManager.playDiceRoll()
                delay(400L)
                val rolled = Random.nextInt(1, 7)
                soundManager.playDiceResult()
                isRollingDice = false

                if (isOnline && repository != null && matchId != null) {
                    repository.updateMatchState(
                        matchId,
                        mapOf(
                            "lastDiceRoll" to rolled.toLong(),
                            "hasRolled" to true
                        )
                    )
                } else {
                    localDiceRoll = rolled
                    localHasRolled = true
                }
            } else if (hasRolled && !isRollingDice) {
                delay(700L)
                val valid = LudoEngine.getValidMovableTokens(currentTokens, activeColor, currentDiceValue)
                if (valid.isNotEmpty()) {
                    val tokenToMove = LudoEngine.chooseBestBotMove(valid, currentTokens, currentDiceValue)
                    val result = LudoEngine.executeMove(currentTokens, tokenToMove, currentDiceValue)

                    if (result.capturedToken != null) soundManager.playCapture()
                    else if (result.reachedGoal) soundManager.playSafeLand()
                    else soundManager.playTokenStep()

                    if (result.winner != null) soundManager.playVictory()

                    if (isOnline && repository != null && matchId != null) {
                        val nextTurnIdx = if (result.grantsExtraRoll) {
                            allColors.indexOf(activeColor)
                        } else {
                            (allColors.indexOf(activeColor) + 1) % allColors.size
                        }
                        repository.updateMatchState(
                            matchId,
                            mapOf(
                                "tokensState" to LudoEngine.serializeTokens(result.updatedTokens),
                                "currentTurnIndex" to nextTurnIdx.toLong(),
                                "currentTurnPlayerId" to allPlayerIds[nextTurnIdx],
                                "hasRolled" to false,
                                "winnerId" to if (result.winner != null) activePlayerId else "",
                                "winnerColor" to if (result.winner != null) activeColor.key else ""
                            )
                        )
                    } else {
                        localTokens = result.updatedTokens
                        localWinner = result.winner
                        if (result.grantsExtraRoll) {
                            localHasRolled = false
                        } else {
                            localActiveColorIndex = (localActiveColorIndex + 1) % allColors.size
                            localHasRolled = false
                        }
                    }
                } else {
                    // No valid moves, pass turn
                    delay(500L)
                    if (isOnline && repository != null && matchId != null) {
                        val nextTurnIdx = (allColors.indexOf(activeColor) + 1) % allColors.size
                        repository.updateMatchState(
                            matchId,
                            mapOf(
                                "currentTurnIndex" to nextTurnIdx.toLong(),
                                "currentTurnPlayerId" to allPlayerIds[nextTurnIdx],
                                "hasRolled" to false
                            )
                        )
                    } else {
                        localActiveColorIndex = (localActiveColorIndex + 1) % allColors.size
                        localHasRolled = false
                    }
                }
            }
        }
    }

    // Auto pass if player has rolled and has 0 valid moves
    LaunchedEffect(hasRolled, movableTokens.size, isRollingDice) {
        if (hasRolled && movableTokens.isEmpty() && !isRollingDice && !isBotTurn && winner == null) {
            delay(1200L)
            if (isOnline && repository != null && matchId != null) {
                val nextTurnIdx = (allColors.indexOf(activeColor) + 1) % allColors.size
                repository.updateMatchState(
                    matchId,
                    mapOf(
                        "currentTurnIndex" to nextTurnIdx.toLong(),
                        "currentTurnPlayerId" to allPlayerIds[nextTurnIdx],
                        "hasRolled" to false
                    )
                )
            } else {
                localActiveColorIndex = (localActiveColorIndex + 1) % allColors.size
                localHasRolled = false
            }
        }
    }

    BackHandler {
        onExitGame()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isOnline) "Room: ${onlineMatch?.roomCode}" else "Pass & Play",
                            fontWeight = FontWeight.Bold,
                            color = LudoGold,
                            fontSize = 18.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onExitGame) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Leave Match",
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NightBackground)
            )
        },
        containerColor = NightBackground
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Player Cards (Red & Green)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    allColors.getOrNull(0)?.let { c ->
                        PlayerCard(
                            playerName = allPlayerNames.getOrElse(0) { "P1" },
                            playerColor = c,
                            isCurrentTurn = activeColor == c,
                            isSpeaking = activeSpeakerName == allPlayerNames.getOrElse(0) { "" },
                            isBot = allPlayerIds.getOrElse(0) { "" }.startsWith("bot_"),
                            finishedTokensCount = currentTokens.filter { it.color == c && it.isFinished }.size,
                            modifier = Modifier.weight(1f).padding(end = 6.dp)
                        )
                    }
                    allColors.getOrNull(1)?.let { c ->
                        PlayerCard(
                            playerName = allPlayerNames.getOrElse(1) { "P2" },
                            playerColor = c,
                            isCurrentTurn = activeColor == c,
                            isSpeaking = activeSpeakerName == allPlayerNames.getOrElse(1) { "" },
                            isBot = allPlayerIds.getOrElse(1) { "" }.startsWith("bot_"),
                            finishedTokensCount = currentTokens.filter { it.color == c && it.isFinished }.size,
                            modifier = Modifier.weight(1f).padding(start = 6.dp)
                        )
                    }
                }

                // Active Turn Banner
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(activeColor.primaryColor.copy(alpha = 0.2f))
                        .border(1.dp, activeColor.primaryColor, RoundedCornerShape(20.dp))
                        .padding(horizontal = 14.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(activeColor.primaryColor)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isMyTurn) "Your Turn! (${activeColor.displayName})" else "$activePlayerName's Turn",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                // Center Ludo Board Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                    contentAlignment = Alignment.Center
                ) {
                    LudoBoard(
                        tokens = currentTokens,
                        movableTokens = if (isMyTurn) movableTokens else emptyList(),
                        onTokenClick = { clickedToken ->
                            if (isMyTurn && movableTokens.contains(clickedToken)) {
                                val result = LudoEngine.executeMove(currentTokens, clickedToken, currentDiceValue)
                                if (result.capturedToken != null) soundManager.playCapture()
                                else if (result.reachedGoal) soundManager.playSafeLand()
                                else soundManager.playTokenStep()

                                if (result.winner != null) soundManager.playVictory()

                                if (isOnline && repository != null && matchId != null) {
                                    scope.launch {
                                        val nextTurnIdx = if (result.grantsExtraRoll) {
                                            allColors.indexOf(activeColor)
                                        } else {
                                            (allColors.indexOf(activeColor) + 1) % allColors.size
                                        }
                                        repository.updateMatchState(
                                            matchId,
                                            mapOf(
                                                "tokensState" to LudoEngine.serializeTokens(result.updatedTokens),
                                                "currentTurnIndex" to nextTurnIdx.toLong(),
                                                "currentTurnPlayerId" to allPlayerIds[nextTurnIdx],
                                                "hasRolled" to false,
                                                "winnerId" to if (result.winner != null) currentUserId else "",
                                                "winnerColor" to if (result.winner != null) activeColor.key else ""
                                            )
                                        )
                                        if (result.winner != null) {
                                            repository.recordGameFinished(isWinner = true)
                                        }
                                    }
                                } else {
                                    localTokens = result.updatedTokens
                                    localWinner = result.winner
                                    if (result.grantsExtraRoll) {
                                        localHasRolled = false
                                    } else {
                                        localActiveColorIndex = (localActiveColorIndex + 1) % allColors.size
                                        localHasRolled = false
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Floating reaction bubble
                    floatingReaction?.let { msg ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1E293B).copy(alpha = 0.95f))
                                .border(1.5.dp, LudoGold, RoundedCornerShape(12.dp))
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = msg,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = LudoGold
                            )
                        }
                    }
                }

                // Bottom Player Cards (Blue & Yellow)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    allColors.getOrNull(3)?.let { c ->
                        PlayerCard(
                            playerName = allPlayerNames.getOrElse(3) { "P4" },
                            playerColor = c,
                            isCurrentTurn = activeColor == c,
                            isSpeaking = activeSpeakerName == allPlayerNames.getOrElse(3) { "" },
                            isBot = allPlayerIds.getOrElse(3) { "" }.startsWith("bot_"),
                            finishedTokensCount = currentTokens.filter { it.color == c && it.isFinished }.size,
                            modifier = Modifier.weight(1f).padding(end = 6.dp)
                        )
                    }
                    allColors.getOrNull(2)?.let { c ->
                        PlayerCard(
                            playerName = allPlayerNames.getOrElse(2) { "P3" },
                            playerColor = c,
                            isCurrentTurn = activeColor == c,
                            isSpeaking = activeSpeakerName == allPlayerNames.getOrElse(2) { "" },
                            isBot = allPlayerIds.getOrElse(2) { "" }.startsWith("bot_"),
                            finishedTokensCount = currentTokens.filter { it.color == c && it.isFinished }.size,
                            modifier = Modifier.weight(1f).padding(start = 6.dp)
                        )
                    }
                }

                // Dice Rolling & Action Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isMyTurn && !hasRolled) "Tap Dice to Roll!"
                            else if (isMyTurn && movableTokens.isNotEmpty()) "Tap a glowing piece to move!"
                            else if (isMyTurn && movableTokens.isEmpty()) "No moves possible with this roll"
                            else "Waiting for ${activeColor.displayName}...",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isMyTurn) LudoGold else TextSecondary
                        )
                        if (hasRolled) {
                            Text(
                                text = "Rolled: $currentDiceValue",
                                fontSize = 11.sp,
                                color = TextPrimary
                            )
                        }
                    }

                    // Interactive Dice
                    DiceView(
                        diceValue = currentDiceValue,
                        isRolling = isRollingDice,
                        canRoll = isMyTurn && !hasRolled && winner == null,
                        onRollClick = {
                            if (isMyTurn && !hasRolled && !isRollingDice && winner == null) {
                                scope.launch {
                                    isRollingDice = true
                                    soundManager.playDiceRoll()
                                    delay(400L)
                                    val rolled = Random.nextInt(1, 7)
                                    soundManager.playDiceResult()
                                    isRollingDice = false

                                    if (isOnline && repository != null && matchId != null) {
                                        repository.updateMatchState(
                                            matchId,
                                            mapOf(
                                                "lastDiceRoll" to rolled.toLong(),
                                                "hasRolled" to true
                                            )
                                        )
                                    } else {
                                        localDiceRoll = rolled
                                        localHasRolled = true
                                    }
                                }
                            }
                        },
                        modifier = Modifier.testTag("interactive_dice")
                    )
                }

                // Voice Chat Controls Bar
                VoiceChatControls(
                    isRecording = isRecordingVoice,
                    isMuted = isVoiceMuted,
                    isPlayingVoice = isPlayingVoice,
                    activeSpeakerName = activeSpeakerName,
                    onStartRecording = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            soundManager.startVoiceRecording()
                        } else {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onStopRecording = {
                        val recordData = soundManager.stopVoiceRecording()
                        if (recordData != null && isOnline && repository != null && matchId != null) {
                            scope.launch {
                                repository.sendMessage(
                                    matchId = matchId,
                                    senderName = "You",
                                    type = "voice",
                                    content = recordData.first,
                                    durationMs = recordData.second
                                )
                            }
                        }
                    },
                    onToggleMute = { soundManager.toggleVoiceMute() },
                    onOpenQuickChat = { showQuickChatModal = true }
                )
            }

            // Quick Chat Modal
            if (showQuickChatModal) {
                QuickChatModal(
                    onDismiss = { showQuickChatModal = false },
                    onSendEmoji = { emoji ->
                        floatingReaction = "You: $emoji"
                        if (isOnline && repository != null && matchId != null) {
                            scope.launch {
                                repository.sendMessage(matchId, "You", "emoji", emoji)
                            }
                        }
                        scope.launch {
                            delay(3000L)
                            floatingReaction = null
                        }
                    },
                    onSendQuickText = { text ->
                        floatingReaction = "You: $text"
                        if (isOnline && repository != null && matchId != null) {
                            scope.launch {
                                repository.sendMessage(matchId, "You", "chat", text)
                            }
                        }
                        scope.launch {
                            delay(3000L)
                            floatingReaction = null
                        }
                    }
                )
            }

            // Victory Dialog Overlay
            if (winner != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.85f)),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = NightSurface),
                        modifier = Modifier
                            .fillMaxWidth(0.88f)
                            .border(2.dp, LudoGold, RoundedCornerShape(20.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = "Trophy",
                                tint = LudoGold,
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "VICTORY!",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                color = LudoGold,
                                letterSpacing = 2.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${winner.displayName} wins the game!",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(20.dp))

                            Button(
                                onClick = onExitGame,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = LudoGold,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("exit_game_button")
                            ) {
                                Text("Return to Home", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
