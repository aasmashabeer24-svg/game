package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.game.engine.GridCoord
import com.example.game.engine.LudoBoardCoordinates
import com.example.game.model.PlayerColor
import com.example.game.model.Token
import com.example.ui.theme.LudoGold
import kotlin.math.hypot
import kotlin.math.min

@Composable
fun LudoBoard(
    tokens: List<Token>,
    movableTokens: List<Token>,
    onTokenClick: (Token) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseGlow"
    )

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .shadow(16.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(tokens, movableTokens) {
                    detectTapGestures { tapOffset ->
                        val cellSize = size.width / 15f
                        // Check if tap hit any movable token
                        var clickedMovableToken: Token? = null
                        var minDistance = Float.MAX_VALUE

                        for (token in movableTokens) {
                            val coord = LudoBoardCoordinates.getTokenGridCoord(token)
                            val tokenCenter = Offset(
                                (coord.col + 0.5f) * cellSize,
                                (coord.row + 0.5f) * cellSize
                            )
                            val dist = hypot(tapOffset.x - tokenCenter.x, tapOffset.y - tokenCenter.y)
                            if (dist < cellSize * 0.9f && dist < minDistance) {
                                minDistance = dist
                                clickedMovableToken = token
                            }
                        }

                        clickedMovableToken?.let { onTokenClick(it) }
                    }
                }
        ) {
            val cellSize = size.width / 15f

            // 1. Draw Board Background
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF131B2E), Color(0xFF0D1322))
                )
            )

            // 2. Draw Four Corner Yards (6x6 cells each)
            drawYard(
                color = PlayerColor.RED,
                topLeft = Offset(0f, 0f),
                size = Size(cellSize * 6f, cellSize * 6f),
                cellSize = cellSize
            )
            drawYard(
                color = PlayerColor.GREEN,
                topLeft = Offset(cellSize * 9f, 0f),
                size = Size(cellSize * 6f, cellSize * 6f),
                cellSize = cellSize
            )
            drawYard(
                color = PlayerColor.BLUE,
                topLeft = Offset(0f, cellSize * 9f),
                size = Size(cellSize * 6f, cellSize * 6f),
                cellSize = cellSize
            )
            drawYard(
                color = PlayerColor.YELLOW,
                topLeft = Offset(cellSize * 9f, cellSize * 9f),
                size = Size(cellSize * 6f, cellSize * 6f),
                cellSize = cellSize
            )

            // 3. Draw Track Cells
            drawTrackGrid(cellSize)

            // 4. Draw Center Goal Triangles
            drawCenterGoal(cellSize)

            // 5. Draw Tokens
            drawAllTokens(
                tokens = tokens,
                movableTokens = movableTokens,
                cellSize = cellSize,
                pulseGlow = pulseGlow
            )
        }
    }
}

private fun DrawScope.drawYard(
    color: PlayerColor,
    topLeft: Offset,
    size: Size,
    cellSize: Float
) {
    // Outer colored quadrant with gradient
    drawRoundRect(
        brush = Brush.radialGradient(
            colors = listOf(color.primaryColor, color.darkColor),
            center = Offset(topLeft.x + size.width / 2f, topLeft.y + size.height / 2f),
            radius = size.width * 0.7f
        ),
        topLeft = topLeft,
        size = size
    )

    // Inner white container
    val innerMargin = cellSize * 0.85f
    val innerTopLeft = Offset(topLeft.x + innerMargin, topLeft.y + innerMargin)
    val innerSize = Size(size.width - innerMargin * 2f, size.height - innerMargin * 2f)
    drawRoundRect(
        color = Color(0xFF0F172A),
        topLeft = innerTopLeft,
        size = innerSize,
        cornerRadius = CornerRadius(16f, 16f)
    )

    // Four token pockets inside yard
    val yardCoords = LudoBoardCoordinates.YARD_COORDS[color] ?: emptyList()
    for (coord in yardCoords) {
        val pocketCenter = Offset((coord.col + 0.5f) * cellSize, (coord.row + 0.5f) * cellSize)
        drawCircle(
            color = color.primaryColor.copy(alpha = 0.35f),
            radius = cellSize * 0.52f,
            center = pocketCenter
        )
        drawCircle(
            color = color.primaryColor,
            radius = cellSize * 0.45f,
            center = pocketCenter,
            style = Stroke(width = 3f)
        )
    }
}

private fun DrawScope.drawTrackGrid(cellSize: Float) {
    val cellStroke = Color(0xFF334155)

    // Draw main track squares
    for ((index, coord) in LudoBoardCoordinates.TRACK_COORDS.withIndex() ) {
        val cellTopLeft = Offset(coord.col * cellSize, coord.row * cellSize)
        val cellRect = Size(cellSize, cellSize)

        var fillColor = Color(0xFF1E293B)
        when (index) {
            0 -> fillColor = PlayerColor.RED.primaryColor.copy(alpha = 0.85f)
            13 -> fillColor = PlayerColor.GREEN.primaryColor.copy(alpha = 0.85f)
            26 -> fillColor = PlayerColor.YELLOW.primaryColor.copy(alpha = 0.85f)
            39 -> fillColor = PlayerColor.BLUE.primaryColor.copy(alpha = 0.85f)
        }

        drawRoundRect(
            color = fillColor,
            topLeft = cellTopLeft,
            size = cellRect,
            cornerRadius = CornerRadius(4f, 4f)
        )
        drawRoundRect(
            color = cellStroke,
            topLeft = cellTopLeft,
            size = cellRect,
            style = Stroke(width = 1.5f),
            cornerRadius = CornerRadius(4f, 4f)
        )

        // Draw Star on Safe Squares
        if (LudoBoardCoordinates.SAFE_TRACK_INDICES.contains(index)) {
            val center = Offset((coord.col + 0.5f) * cellSize, (coord.row + 0.5f) * cellSize)
            drawStarIcon(center, cellSize * 0.28f, LudoGold)
        }
    }

    // Draw colored Home paths (5 cells each)
    drawHomePath(LudoBoardCoordinates.RED_HOME_PATH, PlayerColor.RED.primaryColor, cellSize)
    drawHomePath(LudoBoardCoordinates.GREEN_HOME_PATH, PlayerColor.GREEN.primaryColor, cellSize)
    drawHomePath(LudoBoardCoordinates.YELLOW_HOME_PATH, PlayerColor.YELLOW.primaryColor, cellSize)
    drawHomePath(LudoBoardCoordinates.BLUE_HOME_PATH, PlayerColor.BLUE.primaryColor, cellSize)
}

private fun DrawScope.drawHomePath(coords: List<GridCoord>, color: Color, cellSize: Float) {
    for (coord in coords) {
        val cellTopLeft = Offset(coord.col * cellSize, coord.row * cellSize)
        val cellRect = Size(cellSize, cellSize)
        drawRoundRect(
            brush = Brush.radialGradient(
                colors = listOf(color, color.copy(alpha = 0.7f)),
                center = Offset(cellTopLeft.x + cellSize / 2f, cellTopLeft.y + cellSize / 2f)
            ),
            topLeft = cellTopLeft,
            size = cellRect,
            cornerRadius = CornerRadius(4f, 4f)
        )
        drawRoundRect(
            color = Color(0xFF475569),
            topLeft = cellTopLeft,
            size = cellRect,
            style = Stroke(width = 1.5f),
            cornerRadius = CornerRadius(4f, 4f)
        )
    }
}

private fun DrawScope.drawCenterGoal(cellSize: Float) {
    val centerLeft = cellSize * 6f
    val centerTop = cellSize * 6f
    val centerSize = cellSize * 3f
    val centerPoint = Offset(centerLeft + centerSize / 2f, centerTop + centerSize / 2f)

    // Red Triangle (Left)
    drawPath(
        path = Path().apply {
            moveTo(centerLeft, centerTop)
            lineTo(centerPoint.x, centerPoint.y)
            lineTo(centerLeft, centerTop + centerSize)
            close()
        },
        color = PlayerColor.RED.primaryColor
    )

    // Green Triangle (Top)
    drawPath(
        path = Path().apply {
            moveTo(centerLeft, centerTop)
            lineTo(centerLeft + centerSize, centerTop)
            lineTo(centerPoint.x, centerPoint.y)
            close()
        },
        color = PlayerColor.GREEN.primaryColor
    )

    // Yellow Triangle (Right)
    drawPath(
        path = Path().apply {
            moveTo(centerLeft + centerSize, centerTop)
            lineTo(centerLeft + centerSize, centerTop + centerSize)
            lineTo(centerPoint.x, centerPoint.y)
            close()
        },
        color = PlayerColor.YELLOW.primaryColor
    )

    // Blue Triangle (Bottom)
    drawPath(
        path = Path().apply {
            moveTo(centerLeft, centerTop + centerSize)
            lineTo(centerPoint.x, centerPoint.y)
            lineTo(centerLeft + centerSize, centerTop + centerSize)
            close()
        },
        color = PlayerColor.BLUE.primaryColor
    )

    // Center Gold Emblem
    drawCircle(
        color = Color(0xFF0F172A),
        radius = cellSize * 0.65f,
        center = centerPoint
    )
    drawCircle(
        color = LudoGold,
        radius = cellSize * 0.52f,
        center = centerPoint
    )
    drawStarIcon(centerPoint, cellSize * 0.32f, Color(0xFF1E293B))
}

private fun DrawScope.drawStarIcon(center: Offset, radius: Float, color: Color) {
    val path = Path()
    val points = 5
    val innerRadius = radius * 0.42f
    for (i in 0 until points * 2) {
        val r = if (i % 2 == 0) radius else innerRadius
        val angle = (i * Math.PI / points) - (Math.PI / 2)
        val x = (center.x + r * kotlin.math.cos(angle)).toFloat()
        val y = (center.y + r * kotlin.math.sin(angle)).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    drawPath(path, color, style = Fill)
}

private fun DrawScope.drawAllTokens(
    tokens: List<Token>,
    movableTokens: List<Token>,
    cellSize: Float,
    pulseGlow: Float
) {
    // Group tokens by their grid coordinates so overlapping tokens can be offset
    val tokensByCoord = tokens.groupBy { LudoBoardCoordinates.getTokenGridCoord(it) }

    for ((coord, tokenList) in tokensByCoord) {
        val baseCenter = Offset((coord.col + 0.5f) * cellSize, (coord.row + 0.5f) * cellSize)
        val count = tokenList.size

        tokenList.forEachIndexed { idx, token ->
            val isMovable = movableTokens.any { it.color == token.color && it.id == token.id }
            val offsetDist = if (count > 1) cellSize * 0.16f else 0f
            val angle = if (count > 1) (idx * 2.0 * Math.PI / count) else 0.0
            val tokenCenter = Offset(
                baseCenter.x + (offsetDist * kotlin.math.cos(angle)).toFloat(),
                baseCenter.y + (offsetDist * kotlin.math.sin(angle)).toFloat()
            )

            val tokenRadius = if (count > 1) cellSize * 0.32f else cellSize * 0.38f

            // Pulsing aura if movable
            if (isMovable) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.4f * pulseGlow),
                    radius = tokenRadius * (1.3f + 0.2f * pulseGlow),
                    center = tokenCenter
                )
                drawCircle(
                    color = LudoGold.copy(alpha = 0.8f * pulseGlow),
                    radius = tokenRadius * 1.25f,
                    center = tokenCenter,
                    style = Stroke(width = 3.5f)
                )
            }

            // Shadow
            drawCircle(
                color = Color.Black.copy(alpha = 0.45f),
                radius = tokenRadius,
                center = Offset(tokenCenter.x + 2f, tokenCenter.y + 3f)
            )

            // Token Outer Body (Gradient)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(token.color.lightColor, token.color.primaryColor, token.color.darkColor),
                    center = Offset(tokenCenter.x - tokenRadius * 0.3f, tokenCenter.y - tokenRadius * 0.3f),
                    radius = tokenRadius * 1.2f
                ),
                radius = tokenRadius,
                center = tokenCenter
            )

            // White rim
            drawCircle(
                color = Color.White.copy(alpha = 0.85f),
                radius = tokenRadius,
                center = tokenCenter,
                style = Stroke(width = 2.5f)
            )

            // Center Ring/Gem
            drawCircle(
                color = Color.White.copy(alpha = 0.9f),
                radius = tokenRadius * 0.42f,
                center = tokenCenter
            )
            drawCircle(
                color = token.color.primaryColor,
                radius = tokenRadius * 0.32f,
                center = tokenCenter
            )
        }
    }
}
