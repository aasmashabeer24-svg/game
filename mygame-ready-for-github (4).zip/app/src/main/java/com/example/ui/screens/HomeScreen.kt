package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.MatchRoom
import com.example.data.model.UserProfile
import com.example.data.repository.LudoRepository
import com.example.ui.theme.LudoBlue
import com.example.ui.theme.LudoGold
import com.example.ui.theme.LudoGoldDark
import com.example.ui.theme.LudoGreen
import com.example.ui.theme.LudoRed
import com.example.ui.theme.NightBackground
import com.example.ui.theme.NightSurface
import com.example.ui.theme.NightSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    currentUserId: String,
    repository: LudoRepository,
    onStartLocalGame: (playerCount: Int) -> Unit,
    onJoinOnlineRoom: (matchId: String) -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val userProfile by repository.observeUserProfile(currentUserId).collectAsStateWithLifecycle(initialValue = null)
    val waitingMatches by repository.observeWaitingMatches().collectAsStateWithLifecycle(initialValue = emptyList())

    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showCreateRoomDialog by remember { mutableStateOf(false) }
    var showJoinCodeDialog by remember { mutableStateOf(false) }
    var showLocalGameDialog by remember { mutableStateOf(false) }
    var isActionLoading by remember { mutableStateOf(false) }
    var actionError by remember { mutableStateOf<String?>(null) }

    // Initialize user profile if first launch
    LaunchedEffect(userProfile) {
        if (userProfile == null) {
            val randomNum = Random.nextInt(100, 999)
            repository.saveUserProfile("Player_$randomNum", "avatar_red")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(LudoGold),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("GG", fontWeight = FontWeight.Black, color = Color.Black, fontSize = 16.sp)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "LUDO GG",
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = LudoGold,
                            fontSize = 20.sp
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onSignOut,
                        modifier = Modifier.testTag("sign_out_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "Sign Out",
                            tint = TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NightBackground
                )
            )
        },
        containerColor = NightBackground
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Profile & Stats Card
            item {
                ProfileStatsCard(
                    userProfile = userProfile,
                    onEditName = { showEditProfileDialog = true }
                )
            }

            // 2. Play Modes Grid
            item {
                Text(
                    text = "Select Game Mode",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = LudoGold
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Quick Match
                    PlayModeCard(
                        title = "Quick Match",
                        subtitle = "Instant 4-Player",
                        icon = Icons.Default.Casino,
                        gradient = listOf(Color(0xFF2563EB), Color(0xFF1D4ED8)),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            isActionLoading = true
                            scope.launch {
                                // Find waiting match or create one
                                val existingMatch = waitingMatches.firstOrNull { it.playerIds.size < it.playerCount }
                                if (existingMatch != null) {
                                    val name = userProfile?.displayName ?: "Player"
                                    val color = listOf("red", "green", "yellow", "blue").getOrElse(existingMatch.playerIds.size) { "blue" }
                                    repository.joinMatch(existingMatch.id, name, color)
                                    isActionLoading = false
                                    onJoinOnlineRoom(existingMatch.id)
                                } else {
                                    val name = userProfile?.displayName ?: "Player"
                                    val code = "GG" + Random.nextInt(1000, 9999)
                                    val res = repository.createMatch(code, 4L, name, "red")
                                    isActionLoading = false
                                    res.onSuccess { matchId -> onJoinOnlineRoom(matchId) }
                                }
                            }
                        }
                    )

                    // Pass & Play / Solo vs Bots
                    PlayModeCard(
                        title = "Pass & Play",
                        subtitle = "Solo / Vs Bots",
                        icon = Icons.Default.SmartToy,
                        gradient = listOf(Color(0xFF059669), Color(0xFF047857)),
                        modifier = Modifier.weight(1f),
                        onClick = { showLocalGameDialog = true }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Create Room
                    PlayModeCard(
                        title = "Create Room",
                        subtitle = "Private 6-Digit Code",
                        icon = Icons.Default.Add,
                        gradient = listOf(Color(0xFFD97706), Color(0xFFB45309)),
                        modifier = Modifier.weight(1f),
                        onClick = { showCreateRoomDialog = true }
                    )

                    // Join with Code
                    PlayModeCard(
                        title = "Join Room",
                        subtitle = "Enter Code",
                        icon = Icons.Default.Login,
                        gradient = listOf(Color(0xFF7C3AED), Color(0xFF6D28D9)),
                        modifier = Modifier.weight(1f),
                        onClick = { showJoinCodeDialog = true }
                    )
                }
            }

            // 3. Online Lobbies List
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Live Match Rooms",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = LudoGold
                    )
                    Text(
                        text = "${waitingMatches.size} Waiting",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
            }

            if (waitingMatches.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(NightSurface)
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Groups,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No public rooms waiting right now",
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tap 'Create Room' or 'Quick Match' to start one!",
                                color = LudoGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            } else {
                items(waitingMatches) { match ->
                    MatchRoomRow(
                        match = match,
                        currentUserId = currentUserId,
                        onJoin = {
                            isActionLoading = true
                            scope.launch {
                                val name = userProfile?.displayName ?: "Player"
                                val color = listOf("red", "green", "yellow", "blue").getOrElse(match.playerIds.size) { "blue" }
                                repository.joinMatch(match.id, name, color)
                                isActionLoading = false
                                onJoinOnlineRoom(match.id)
                            }
                        }
                    )
                }
            }
        }
    }

    // --- DIALOGS ---

    // 1. Edit Name Dialog
    if (showEditProfileDialog) {
        var newName by remember { mutableStateOf(userProfile?.displayName ?: "") }
        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Edit Display Name", color = LudoGold) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { if (it.length <= 20) newName = it },
                    label = { Text("Your Name") },
                    singleLine = true,
                    modifier = Modifier.testTag("edit_name_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newName.isNotBlank()) {
                            scope.launch {
                                repository.saveUserProfile(newName.trim(), userProfile?.avatarId ?: "avatar_red")
                            }
                            showEditProfileDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LudoGold, contentColor = Color.Black)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = NightSurface
        )
    }

    // 2. Create Room Dialog
    if (showCreateRoomDialog) {
        var selectedPlayers by remember { mutableStateOf(4) }
        AlertDialog(
            onDismissRequest = { showCreateRoomDialog = false },
            title = { Text("Create Multiplayer Room", color = LudoGold) },
            text = {
                Column {
                    Text("Select Player Capacity:", color = TextPrimary, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(2, 3, 4).forEach { count ->
                            Button(
                                onClick = { selectedPlayers = count },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedPlayers == count) LudoGold else NightSurfaceVariant,
                                    contentColor = if (selectedPlayers == count) Color.Black else TextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("$count Players")
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCreateRoomDialog = false
                        isActionLoading = true
                        scope.launch {
                            val code = "GG" + Random.nextInt(1000, 9999)
                            val name = userProfile?.displayName ?: "Host"
                            val res = repository.createMatch(code, selectedPlayers.toLong(), name, "red")
                            isActionLoading = false
                            res.onSuccess { matchId -> onJoinOnlineRoom(matchId) }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LudoGold, contentColor = Color.Black)
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateRoomDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = NightSurface
        )
    }

    // 3. Join with Code Dialog
    if (showJoinCodeDialog) {
        var inputCode by remember { mutableStateOf("") }
        var codeError by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showJoinCodeDialog = false },
            title = { Text("Join Room with Code", color = LudoGold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = inputCode,
                        onValueChange = { inputCode = it.uppercase().take(8) },
                        label = { Text("Enter 6-character Code (e.g. GG1234)") },
                        singleLine = true,
                        modifier = Modifier.testTag("room_code_input")
                    )
                    codeError?.let {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(it, color = LudoRed, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = inputCode.trim()
                        val match = waitingMatches.firstOrNull { it.roomCode.equals(trimmed, ignoreCase = true) }
                        if (match != null) {
                            showJoinCodeDialog = false
                            isActionLoading = true
                            scope.launch {
                                val name = userProfile?.displayName ?: "Player"
                                val color = listOf("red", "green", "yellow", "blue").getOrElse(match.playerIds.size) { "blue" }
                                repository.joinMatch(match.id, name, color)
                                isActionLoading = false
                                onJoinOnlineRoom(match.id)
                            }
                        } else {
                            codeError = "Room not found or not waiting. Check code."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LudoGold, contentColor = Color.Black)
                ) {
                    Text("Join")
                }
            },
            dismissButton = {
                TextButton(onClick = { showJoinCodeDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = NightSurface
        )
    }

    // 4. Pass & Play Dialog
    if (showLocalGameDialog) {
        var localPlayerCount by remember { mutableStateOf(4) }
        AlertDialog(
            onDismissRequest = { showLocalGameDialog = false },
            title = { Text("Pass & Play / Bots", color = LudoGold) },
            text = {
                Column {
                    Text("Choose number of players (AI bots fill empty slots):", color = TextPrimary, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(2, 3, 4).forEach { count ->
                            Button(
                                onClick = { localPlayerCount = count },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (localPlayerCount == count) LudoGold else NightSurfaceVariant,
                                    contentColor = if (localPlayerCount == count) Color.Black else TextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("$count Players")
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLocalGameDialog = false
                        onStartLocalGame(localPlayerCount)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LudoGold, contentColor = Color.Black)
                ) {
                    Text("Start Game")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLocalGameDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = NightSurface
        )
    }
}

@Composable
private fun ProfileStatsCard(
    userProfile: UserProfile?,
    onEditName: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NightSurface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(LudoGold, LudoGoldDark)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userProfile?.displayName?.take(1)?.uppercase() ?: "P",
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            fontSize = 20.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = userProfile?.displayName ?: "Loading...",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            IconButton(onClick = onEditName, modifier = Modifier.size(24.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Name",
                                    tint = LudoGold,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Text(
                            text = "Ludo GG Champion",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Stat counters
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NightSurfaceVariant)
                    .padding(vertical = 10.dp, horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                val played = userProfile?.gamesPlayed ?: 0L
                val won = userProfile?.gamesWon ?: 0L
                val winRate = if (played > 0) ((won.toFloat() / played) * 100).toInt() else 0

                StatItem(label = "Played", value = "$played")
                StatItem(label = "Victories", value = "$won", highlight = true)
                StatItem(label = "Win Rate", value = "$winRate%")
            }
        }
    }
}

@Composable
private fun StatItem(label: String, value: String, highlight: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = if (highlight) LudoGold else TextPrimary
        )
        Text(
            text = label,
            fontSize = 11.sp,
            color = TextSecondary
        )
    }
}

@Composable
private fun PlayModeCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    gradient: List<Color>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(100.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(gradient))
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
            Column {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
private fun MatchRoomRow(
    match: MatchRoom,
    currentUserId: String,
    onJoin: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NightSurface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(NightSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${match.playerIds.size}/${match.playerCount}",
                        fontWeight = FontWeight.Bold,
                        color = LudoGold,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Room ${match.roomCode}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Host: ${match.playerNames.firstOrNull() ?: "Unknown"}",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
            }

            Button(
                onClick = onJoin,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (match.playerIds.contains(currentUserId)) Color(0xFF10B981) else LudoGold,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (match.playerIds.contains(currentUserId)) "Rejoin" else "Join",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}
