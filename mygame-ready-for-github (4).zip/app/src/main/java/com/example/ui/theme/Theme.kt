package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LudoDarkColorScheme = darkColorScheme(
    primary = LudoGold,
    onPrimary = Color.Black,
    primaryContainer = LudoGoldDark,
    onPrimaryContainer = LudoGoldLight,
    secondary = AccentCyan,
    onSecondary = Color.Black,
    secondaryContainer = NightSurfaceHighlight,
    onSecondaryContainer = Color.White,
    tertiary = AccentPurple,
    background = NightBackground,
    onBackground = TextPrimary,
    surface = NightSurface,
    onSurface = TextPrimary,
    surfaceVariant = NightSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = NightSurfaceHighlight,
    error = LudoRed,
    onError = Color.White
)

@Composable
fun LudoGGTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LudoDarkColorScheme,
        typography = Typography,
        content = content
    )
}
