package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LudoGold
import com.example.ui.theme.LudoGoldLight
import kotlinx.coroutines.launch

@Composable
fun DiceView(
    diceValue: Int,
    isRolling: Boolean,
    canRoll: Boolean,
    onRollClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 64.dp
) {
    val rotationAnim = remember { Animatable(0f) }
    val scaleAnim = remember { Animatable(1f) }

    LaunchedEffect(isRolling) {
        if (isRolling) {
            launch {
                rotationAnim.animateTo(
                    targetValue = 360f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(240, easing = LinearEasing),
                        repeatMode = RepeatMode.Restart
                    )
                )
            }
            launch {
                scaleAnim.animateTo(
                    targetValue = 1.15f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(120),
                        repeatMode = RepeatMode.Reverse
                    )
                )
            }
        } else {
            rotationAnim.snapTo(0f)
            scaleAnim.animateTo(1f, tween(150))
        }
    }

    Box(
        modifier = modifier
            .size(size)
            .scale(scaleAnim.value)
            .rotate(rotationAnim.value)
            .shadow(
                elevation = if (canRoll) 10.dp else 2.dp,
                shape = RoundedCornerShape(14.dp),
                spotColor = if (canRoll) LudoGold else Color.Black
            )
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = canRoll && !isRolling) {
                onRollClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val cornerRadius = size.toPx() * 0.22f
            val canvasSize = size.toPx()

            // 1. Background gradient
            val diceBrush = if (canRoll) {
                Brush.linearGradient(
                    colors = listOf(Color(0xFFFFFBEB), Color(0xFFFEF3C7), Color(0xFFFDE68A)),
                    start = Offset(0f, 0f),
                    end = Offset(canvasSize, canvasSize)
                )
            } else {
                Brush.linearGradient(
                    colors = listOf(Color(0xFFE2E8F0), Color(0xFFCBD5E1)),
                    start = Offset(0f, 0f),
                    end = Offset(canvasSize, canvasSize)
                )
            }

            drawRoundRect(
                brush = diceBrush,
                size = Size(canvasSize, canvasSize),
                cornerRadius = CornerRadius(cornerRadius, cornerRadius)
            )

            // 2. Glowing rim if can roll
            if (canRoll) {
                drawRoundRect(
                    color = LudoGold,
                    size = Size(canvasSize, canvasSize),
                    style = Stroke(width = 3.5f),
                    cornerRadius = CornerRadius(cornerRadius, cornerRadius)
                )
            }

            // 3. Draw Dots (Pips)
            val dotColor = if (canRoll) Color(0xFF92400E) else Color(0xFF334155)
            val dotRadius = canvasSize * 0.088f

            val left = canvasSize * 0.26f
            val mid = canvasSize * 0.50f
            val right = canvasSize * 0.74f

            val top = canvasSize * 0.26f
            val center = canvasSize * 0.50f
            val bottom = canvasSize * 0.74f

            when (diceValue.coerceIn(1, 6)) {
                1 -> {
                    drawCircle(dotColor, dotRadius * 1.3f, Offset(mid, center))
                }
                2 -> {
                    drawCircle(dotColor, dotRadius, Offset(left, top))
                    drawCircle(dotColor, dotRadius, Offset(right, bottom))
                }
                3 -> {
                    drawCircle(dotColor, dotRadius, Offset(left, top))
                    drawCircle(dotColor, dotRadius, Offset(mid, center))
                    drawCircle(dotColor, dotRadius, Offset(right, bottom))
                }
                4 -> {
                    drawCircle(dotColor, dotRadius, Offset(left, top))
                    drawCircle(dotColor, dotRadius, Offset(right, top))
                    drawCircle(dotColor, dotRadius, Offset(left, bottom))
                    drawCircle(dotColor, dotRadius, Offset(right, bottom))
                }
                5 -> {
                    drawCircle(dotColor, dotRadius, Offset(left, top))
                    drawCircle(dotColor, dotRadius, Offset(right, top))
                    drawCircle(dotColor, dotRadius, Offset(mid, center))
                    drawCircle(dotColor, dotRadius, Offset(left, bottom))
                    drawCircle(dotColor, dotRadius, Offset(right, bottom))
                }
                6 -> {
                    drawCircle(dotColor, dotRadius, Offset(left, top))
                    drawCircle(dotColor, dotRadius, Offset(right, top))
                    drawCircle(dotColor, dotRadius, Offset(left, center))
                    drawCircle(dotColor, dotRadius, Offset(right, center))
                    drawCircle(dotColor, dotRadius, Offset(left, bottom))
                    drawCircle(dotColor, dotRadius, Offset(right, bottom))
                }
            }
        }
    }
}
