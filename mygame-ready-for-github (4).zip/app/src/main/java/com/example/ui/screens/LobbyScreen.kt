package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.LudoRepository
import com.example.game.engine.LudoEngine
import com.example.game.model.PlayerColor
import com.example.ui.theme.LudoGold
import com.example.ui.theme.NightBackground
import com.example.ui.theme.NightSurface
import com.example.ui.theme.NightSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LobbyScreen(
    matchId: String,
    currentUserId: String,
    repository: LudoRepository,
    onGameStarted: () -> Unit,
    onLeaveLobby: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val match by repository.observeMatch(matchId).collectAsStateWithLifecycle(initialValue = null)

    // Automatically navigate to game when status changes to 'playing'
    LaunchedEffect(match?.status) {
        if (match?.status == "playing") {
            onGameStarted()
        }
    }

    BackHandler {
        onLeaveLobby()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Game Lobby", color = LudoGold, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onLeaveLobby) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Leave Lobby",
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NightBackground)
            )
        },
        containerColor = NightBackground
    ) { innerPadding ->
        val currentMatch = match
        if (currentMatch == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = LudoGold)
            }
            return@Scaffold
        }

        val isHost = currentMatch.hostId == currentUserId
        val maxSlots = currentMatch.playerCount.toInt()
        val allColors = listOf("red", "green", "yellow", "blue")

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Room Code Card
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NightSurface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ROOM CODE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = currentMatch.roomCode,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                color = LudoGold,
                                letterSpacing = 2.sp
                            )
                        }

                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Ludo GG Room Code", currentMatch.roomCode))
                                Toast.makeText(context, "Code copied to clipboard!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(NightSurfaceVariant)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy Room Code",
                                tint = LudoGold
                            )
                        }
                    }
                }

                Text(
                    text = "Players (${currentMatch.playerIds.size}/$maxSlots)",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                // Player Slots List
                for (i in 0 until maxSlots) {
                    val colorKey = allColors.getOrElse(i) { "red" }
                    val playerColor = PlayerColor.fromKey(colorKey)
                    val isOccupied = i < currentMatch.playerIds.size

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isOccupied) NightSurfaceVariant else NightSurface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = if (isOccupied) playerColor.primaryColor else Color(0xFF334155),
                                shape = RoundedCornerShape(12.dp)
                            )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(playerColor.primaryColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isOccupied) currentMatch.playerNames[i].take(1).uppercase() else "${i + 1}",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (isOccupied) currentMatch.playerNames[i] else "Empty Slot",
                                        fontWeight = FontWeight.Bold,
                                        color = if (isOccupied) TextPrimary else TextSecondary,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = playerColor.displayName + if (i == 0) " (Host)" else "",
                                        color = playerColor.lightColor,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            if (!isOccupied && isHost) {
                                Button(
                                    onClick = {
                                        scope.launch {
                                            val botNames = listOf("Bot Alex", "Bot Zoe", "Bot Leo", "Bot Mia")
                                            val botName = botNames.getOrElse(i) { "Bot $i" }
                                            val botId = "bot_${System.currentTimeMillis()}_$i"
                                            val newIds = currentMatch.playerIds + botId
                                            val newNames = currentMatch.playerNames + botName
                                            val newColors = currentMatch.playerColors + colorKey
                                            repository.updateMatchState(
                                                matchId,
                                                mapOf(
                                                    "playerIds" to newIds,
                                                    "playerNames" to newNames,
                                                    "playerColors" to newColors
                                                )
                                            )
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF2563EB),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("add_bot_button_$i")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.SmartToy,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Bot", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Action: Start Game (Host only) or Waiting Status
            Column(modifier = Modifier.fillMaxWidth()) {
                if (isHost) {
                    val canStart = currentMatch.playerIds.size >= 2
                    Button(
                        onClick = {
                            scope.launch {
                                val activeColors = currentMatch.playerColors.map { PlayerColor.fromKey(it) }
                                val initialTokens = LudoEngine.createInitialTokens(activeColors)
                                val serializedTokens = LudoEngine.serializeTokens(initialTokens)

                                repository.updateMatchState(
                                    matchId,
                                    mapOf(
                                        "status" to "playing",
                                        "currentTurnIndex" to 0L,
                                        "currentTurnPlayerId" to currentMatch.playerIds[0],
                                        "lastDiceRoll" to 6L,
                                        "hasRolled" to false,
                                        "tokensState" to serializedTokens
                                    )
                                )
                                onGameStarted()
                            }
                        },
                        enabled = canStart,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = LudoGold,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("start_game_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (canStart) "Start Game" else "Need at least 2 players",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(NightSurface)
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Waiting for Host to start the game...",
                            color = LudoGold,
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}
