package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Ludo GG Vibrant Game Palette
val LudoGold = Color(0xFFF59E0B)
val LudoGoldLight = Color(0xFFFDE68A)
val LudoGoldDark = Color(0xFFB45309)

val LudoRed = Color(0xFFEF4444)
val LudoGreen = Color(0xFF10B981)
val LudoYellow = Color(0xFFFBBF24)
val LudoBlue = Color(0xFF3B82F6)

val NightBackground = Color(0xFF0B0F19)
val NightSurface = Color(0xFF151D30)
val NightSurfaceVariant = Color(0xFF1E293B)
val NightSurfaceHighlight = Color(0xFF334155)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val AccentCyan = Color(0xFF06B6D4)
val AccentPurple = Color(0xFF8B5CF6)
