package com.example

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.repository.LudoRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class LudoRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun saveUserProfile_authenticatedUser_succeeds() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repository = LudoRepository(firestore)

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.saveUserProfile("Alice", "avatar_red")
        }
        assertTrue("Expected saveUserProfile to succeed", result.isSuccess)

        val profile = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.observeUserProfile(aliceUid).first { it != null }
        }
        assertNotNull(profile)
        assertEquals("Alice", profile?.displayName)
    }

    @Test
    fun createAndObserveMatch_authenticatedUser_succeeds() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repository = LudoRepository(firestore)

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createMatch("LUDO12", 4L, "Alice", "red")
        }
        assertTrue("Expected createMatch to succeed", createResult.isSuccess)
        val matchId = createResult.getOrThrow()
        assertTrue(matchId.isNotEmpty())

        val matches = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeWaitingMatches().first { list -> list.any { it.id == matchId } }
        }
        assertTrue(matches.any { it.id == matchId })
    }

    @Test
    fun observeWaitingMatches_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = LudoRepository(firestore)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeWaitingMatches().first()
            }
            fail("Expected exception when unauthenticated")
        } catch (e: Exception) {
            val firestoreException = checkNotNull(e.unwrapFirestoreException()) {
                "Expected nested FirebaseFirestoreException, got $e"
            }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
        }
    }

    @Test
    fun sendMessage_nonParticipant_failsWithPermissionDenied() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val aliceRepo = LudoRepository(firestore)
        val matchId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createMatch("LUDO99", 2L, "Alice", "red").getOrThrow()
        }

        // Bob signs in and tries to send message into Alice's match without joining
        signInTestUser(BOB_EMAIL)
        val bobRepo = LudoRepository(firestore)
        val messageResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.sendMessage(matchId, "Bob", "chat", "Intruder message")
        }
        assertTrue("Expected sendMessage to fail for non-participant", messageResult.isFailure)
        val exception = messageResult.exceptionOrNull()
        val firestoreException = exception?.unwrapFirestoreException()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
    }

    private companion object {
        const val ALICE_EMAIL = "alice@ludogg.test"
        const val BOB_EMAIL = "bob@ludogg.test"
        const val DEFAULT_TIMEOUT_MS = 6000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}
