const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

// --- SECURITY BOUNDS TESTS ---

test("Unauthenticated user: cannot read user profiles or matches", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").get());
  await assertFails(unauthDb.collection("matches").get());
});

test("Authenticated user: can create and read their own profile", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const profileRef = aliceDb.collection("users").doc(ALICE_UID);
  
  await assertSucceeds(profileRef.set({
    userId: ALICE_UID,
    displayName: "Alice",
    avatarId: "avatar_red",
    gamesPlayed: 0,
    gamesWon: 0,
    createdAt: new Date(),
    updatedAt: new Date()
  }));

  await assertSucceeds(profileRef.get());
});

test("Authenticated user: cannot update another user's profile", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("users").doc(BOB_UID).set({
      userId: BOB_UID,
      displayName: "Bob",
      avatarId: "avatar_blue",
      gamesPlayed: 1,
      gamesWon: 0,
      createdAt: new Date(),
      updatedAt: new Date()
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("users").doc(BOB_UID).update({
    displayName: "Hacked"
  }));
});

test("Authenticated user: can create and query matches", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const matchRef = aliceDb.collection("matches").doc("match_1");

  await assertSucceeds(matchRef.set({
    id: "match_1",
    roomCode: "GG1234",
    hostId: ALICE_UID,
    status: "waiting",
    playerCount: 4,
    playerIds: [ALICE_UID],
    playerNames: ["Alice"],
    playerColors: ["red"],
    currentTurnIndex: 0,
    currentTurnPlayerId: ALICE_UID,
    lastDiceRoll: 6,
    hasRolled: false,
    tokensState: "{}",
    winnerId: "",
    winnerColor: "",
    createdAt: new Date(),
    updatedAt: new Date()
  }));

  // Alice can list waiting matches
  await assertSucceeds(
    aliceDb.collection("matches").where("status", "==", "waiting").get()
  );
});

test("Parent Gate: Only match participants can send messages", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("matches").doc("match_1").set({
      id: "match_1",
      roomCode: "GG1234",
      hostId: ALICE_UID,
      status: "playing",
      playerCount: 2,
      playerIds: [ALICE_UID],
      playerNames: ["Alice"],
      playerColors: ["red"],
      currentTurnIndex: 0,
      currentTurnPlayerId: ALICE_UID,
      lastDiceRoll: 1,
      hasRolled: false,
      tokensState: "{}",
      winnerId: "",
      winnerColor: "",
      createdAt: new Date(),
      updatedAt: new Date()
    });
  });

  // Bob is NOT in match_1 playerIds, so Bob cannot send message
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("matches").doc("match_1").collection("messages").doc("msg_bob").set({
      id: "msg_bob",
      matchId: "match_1",
      senderId: BOB_UID,
      senderName: "Bob",
      type: "chat",
      content: "Hello",
      durationMs: 0,
      createdAt: new Date()
    })
  );

  // Alice IS in match_1 playerIds, so Alice CAN send message
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("matches").doc("match_1").collection("messages").doc("msg_alice").set({
      id: "msg_alice",
      matchId: "match_1",
      senderId: ALICE_UID,
      senderName: "Alice",
      type: "chat",
      content: "Hello from Alice",
      durationMs: 0,
      createdAt: new Date()
    })
  );
});
